package com.practice;

public class BooleanTest {
	int a, b;
	BooleanTest(int i, int j){
		a=i;
		b=j;
	}
	boolean equalTo(BooleanTest bt){
		return (bt.a==a&&bt.b==b);
	}
	public static void main(String args[]){
		BooleanTest bl1= new BooleanTest(10,20);
		BooleanTest bl2= new BooleanTest(10,20);
		BooleanTest bl3 = new BooleanTest(12,23);
		
		System.out.println("bl1==bl2:"+bl1.equalTo(bl2));
		System.out.println("bl2==bl3:"+bl2.equalTo(bl3));
	}

}
