package com.practice;

public class Passing {
	public static void main(String args[]){
		int x = 5;
		System.out.println(x);
	
		change(x);
	}
	public static void change(int x){
		x=10;
	}

}
