package com.practice;

public class Box {
	
	double height,width,depth;
	Box(Box ob){
		height=ob.height;
		width=ob.width;
		depth=ob.depth;
	}
	Box (double h, double w, double d){
		height=h;
		width=w;
		depth=d;
	}
	double volume(){
		return height*width*depth;
	}
	
	public static void main(String args[]){
		Box b=new Box(10,20,36);
		Box b1=new Box(12,21,45);
		double vol;
		vol=b.volume();
		System.out.println("box valume:"+vol);
		vol=b1.volume();
		System.out.println("box valume:"+vol);
	}

}
