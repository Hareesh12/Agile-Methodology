package com.datatype;

public class Overflow {
	public static void main(String []args){
		//over flow
		int a = 130;
		byte b = (byte)a;
		System.out.println(" int value ="+ a);
		System.out.println("byte value=" + b);
	}

}
