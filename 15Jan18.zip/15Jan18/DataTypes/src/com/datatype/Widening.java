package com.datatype;

public class Widening {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10;
		float b = a;
		System.out.println("Int value="+ a);
		System.out.println("Float value=" + b);
	}

}
