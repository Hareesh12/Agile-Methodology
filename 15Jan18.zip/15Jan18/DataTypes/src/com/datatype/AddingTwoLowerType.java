package com.datatype;

public class AddingTwoLowerType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a = 10;
		byte b = 10;
		byte c = (byte)(a+b);
		System.out.println("lower value ="+ c);

	}

}
