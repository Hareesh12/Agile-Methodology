package com.datatype;

public class Int {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a= 2147483648;
		//int b = 2147483648l;
		int c = 2147483647;
		System.out.println("c value=" + c);
		

	}

}
