package com.datatype;

public class Short {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// this is mostly rarely used datatype in java
		
	}

}
