package com.datatype;

public class Narrowing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float f = 10.5f;
		//int a = f; this is compile time error
		int a = (int)f;
		System.out.println("float value="+ f);
		System.out.println("int value ="+ a);

	}

}
