package com.datatype;

public class Byte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a = 127;
		byte b = -128;
		//byte c = 10.4; this is a double value
		System.out.println("value a=" + a);
		System.out.println(" value b =" + b);

	}

}
