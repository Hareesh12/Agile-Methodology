package com.operators;

public class PresedenceArthemeticOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20,b=10,c=30,d=50,e=40;
		System.out.println("value of a+b/2="+ (a+b/2));
		System.out.println("value of a-b*c+d/e="+ (a-b*c+d/e));

	}

}
