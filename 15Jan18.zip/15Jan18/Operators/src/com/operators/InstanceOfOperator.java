package com.operators;

public class InstanceOfOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj1 = new Person();
		Person obj2 = new Boy();
		System.out.println("instance of person:"+ (obj1 instanceof Person));
		System.out.println("instance of Boy:" + (obj1 instanceof Boy));
		System.out.println("Instanceof Interface:" + (obj1 instanceof MyInterface));
		System.out.println("instance of person:" + (obj2 instanceof Person));
		System.out.println("instance of Boy:"+(obj2 instanceof Boy));
		System.out.println("instance of MyInterface"+(obj2 instanceof MyInterface));
		
	}

}

		class Person{
			
		}
		class Boy extends Person implements MyInterface{
			
		}
		interface MyInterface{
			
		}
		
		
		
		
		
		

