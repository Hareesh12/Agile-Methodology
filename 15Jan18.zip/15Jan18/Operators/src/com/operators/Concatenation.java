package com.operators;

public class Concatenation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5,y=8;
		System.out.println("Concatenation valu (x+y)="+x+y);
		System.out.println("value of (x+y)="+(x+y));

	}

}
