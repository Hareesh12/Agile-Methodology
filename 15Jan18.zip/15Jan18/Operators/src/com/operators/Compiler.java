package com.operators;

public class Compiler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10, b=20,c=30;
		a=b+++c;
		System.out.println("value of a="+ a+" "+ b+" ");
	}

}
