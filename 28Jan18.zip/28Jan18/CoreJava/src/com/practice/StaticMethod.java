package com.practice;

public class StaticMethod {
	
	static void m1(){
		System.out.println("from m1");
	}
	public static void main(String []args){
		m1();
		
	}

}
