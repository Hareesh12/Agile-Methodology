package com.practice;

public class Test2 {
	
	//static variable
	static int a= 10;
	// static block
	static {
		System.out.println("from static block");
	}
	//static method
	static int m1(){
		a=20;
		System.out.println("from m1");
		// Cannot make a static reference to the non-static field b
       // compilation error
		b=15;//
		// Cannot make a static reference to the 
        // non-static method m2() from the type Test
		//compilation error
		m2();
		//we cannot use super keyword in static context
		System.out.println(super.a);
		
	}
	//instance method
	void m2(){
		System.out.println("from m2()");
	}
	
	public static void main (String args[]){
		//main method
	}

}
