package com.practice;

public class StaticBlock1 {
	
	static int i;
	int j;
	static{
		i = 10;
		System.out.println("static block intialized");
		
	}

	public static void main(String args[]){
		System.out.println(StaticBlock1.i);
		
	}

}
