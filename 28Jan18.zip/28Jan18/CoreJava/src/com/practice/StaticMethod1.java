package com.practice;

public class StaticMethod1 {
	

}



//they can only directly call other static methods
//they can only directly access static data
//they cannot refer 'this' or 'super' in any way