package com.practice;

public class StaticBlock2 {

	static int i;
	int j;
	static{
		i=20;
		System.out.println("static block called");
	}
	StaticBlock2(){
		System.out.println("Constructor");
	}
	public static void main(String args[]){
		
		
		StaticBlock2 sb1 = new StaticBlock2();
		StaticBlock2 sb2 = new StaticBlock2();
	
		System.out.println(StaticBlock2.i);
	}
}
