package com.practice;

public class Test1 {
	//static variable
	static int a= k1();

	//static block
	static {
		System.out.println("static block intialized");
	}
	//static method
	static int k1(){
		System.out.println("static method");
		return 20;
	}
	public static void main(String args[]){
		System.out.println("from main");
		System.out.println("value of 1="+ a);
	}

}
