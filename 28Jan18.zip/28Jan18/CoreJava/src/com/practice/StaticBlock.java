package com.practice;

public class StaticBlock {
	static int a=5;
	static int b;
	static {
		System.out.println("static block intialized");
		b = a*3;
	}
	public static void main(String args[]){
		
		System.out.println("from static bock");
		System.out.println(b);
		System.out.println(a+b);
	}

}
