package com.practice;

public class Test {
	public static void main(String args[]){
		Test t = new Test();
		t.m2();
		System.out.println("");
	}
		public void m2(){
			int i = 10;
			int j = 20;
		int	k=i+j;
		
		System.out.println(k);
		}

}
