package CreateObjects;

public class NewObject {

	String name ="Hareesh";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NewObject ob = new NewObject();
		System.out.println(ob.name);
	}

}
