package Overloading.com;

public class DataTypeChange {
	public int add(int a, int b, int c){
		int sum = a+b-c;
		return sum;
	}

	public double add(double a,double b, double c){
		double sum =a-b+c;
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DataTypeChange ch = new DataTypeChange();
		
		int sum1 = ch.add(1,2,3);
		System.out.println("Integer value=" +sum1);
	
		double sum2 = ch.add(1.2, 2.5, 3.6);
		System.out.println("double value=" + sum2);
	}

}
