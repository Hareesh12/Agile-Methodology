package Overloading.com;

public class Null {
	public void fun(Integer i){
		System.out.println("fun(integer)");
	}
	public void fun(String name){
		System.out.println("fun(string)");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Null n = new Null();
		n.fun(null);

	}

}
