package Overloading.com;

public class Test {

	public void fun(Integer i){
		System.out.println("fun(integer)");
	}
	public void fun(String name){
		System.out.println("fun(fun)");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test t = new Test();
		Integer arg = null;
		String ag1 = null;
		t.fun(arg);
		t.fun(ag1);
		
	}

}
