package Overloading.com;

public class DiffReturn {
	public int add(int a, int b){
		int sum = a+b;
		return sum;
	}

	public double add(int a,int b){
		double sum = a+b;
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DiffReturn dr = new DiffReturn();
		int sum1 = dr.add(1, 5);
		System.out.println("integer value:"+sum1);
		Double sum2 = dr.add(1.0,2.3);
	
		System.out.println("double value:"+sum2);
	}
	

}
