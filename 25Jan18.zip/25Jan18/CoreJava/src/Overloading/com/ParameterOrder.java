package Overloading.com;

public class ParameterOrder {
	public void rock(String name,int id){
		System.out.println("Name:"+name+" "+"Id:"+id);
	
	}
	public void rock(int id,String name){
		System.out.println("Name:"+name+" "+"Id:"+id);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ParameterOrder po =new ParameterOrder();
	
		po.rock("Hare", 1);
		po.rock( "ram",2);
	}

}
