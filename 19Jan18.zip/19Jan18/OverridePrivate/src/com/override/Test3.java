package com.override;

public class Test3 {
	void m1(){
		System.out.println("m1 method");
	}
	void m2(){
		System.out.println("m2 method");
	}
}
	class Derived3 extends Test3{
		@Override
		 // no issue while throwing unchecked exception
		void m1()throws ArithmeticException{
		System.out.println("Derived m1");	
		}
		@Override
		// compile-time error
	    // issue while throwin checked exception
		void m2()throws Exception{
			System.out.println("derived m2");
		}
	
}
