package com.override;
//We can call parent class method in overriding method using super keyword.
public class Test2 {

	public void show(){
		System.out.println("show test");
	}
}
class Derived2 extends Test2{
	public void show(){
		super.show();
		System.out.println("show derived");
	}
}
