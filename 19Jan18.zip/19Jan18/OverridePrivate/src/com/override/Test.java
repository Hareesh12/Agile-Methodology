package com.override;

public class Test {

	public void fun(){
		System.out.println("5");
	}}

class Derived extends Test{
	public void fun(){
		System.out.println("gh");
	}

}
