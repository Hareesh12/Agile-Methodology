package com.override;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test1 obj=new Derived1();
		obj.fun();
	}

}
