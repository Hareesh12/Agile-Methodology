package com.override;

public class Outer {

	private String msg="geeks";
	private void fun(){
		System.out.println("outer fun()");
	}

class Inner extends Outer{
	private void fun(){
		System.out.println("accesing member outer:" + msg);
	}
}
public static void main(String args[]){
	Outer o=new Outer();
	Inner i = o.new Inner();
	i.fun();
	o.fun();
}
}