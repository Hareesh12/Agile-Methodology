package com.override;

public class Test1 {

	private void fun(){
		System.out.println("Base fun");
	}
}

class Derived1 extends Test1{
	private void fun(){
		System.out.println("Derived fun");
	}
}