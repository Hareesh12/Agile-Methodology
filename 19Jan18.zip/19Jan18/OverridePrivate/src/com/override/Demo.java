package com.override;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test obj1= new Derived();
		obj1.fun();
	}

}
