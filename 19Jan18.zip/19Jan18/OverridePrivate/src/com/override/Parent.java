package com.override;

public class Parent {
	void m1()throws RuntimeException{
		System.out.println("hareesh");
	}

}
class Child extends Parent{
	void m1()throws RuntimeException{
		System.out.println("Ramesh");
	}
}
class Child1 extends Parent{
	void m1()throws ArithmeticException{
		System.out.println("naresh");
	}
}
class Child2 extends Parent{
	void m1(){
		System.out.println("mahesh");
	}
}
class Child3 extends Parent{
	void m1()throws Exception{
		System.out.println("ram");
	}
}