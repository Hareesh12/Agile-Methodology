package com.java;

import java.io.*;

public class Deserialization implements Serializable {
	public String name;
	Deserialization(String name){
		this.name = name;
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
			Deserialization d = new Deserialization("Geeeks");
			FileOutputStream f = new  FileOutputStream("file.text()");
			ObjectOutputStream oos= new ObjectOutputStream(f);
			oos.writeObject(d);
			oos.close();
			f.close();
			
		}

		catch(Exception e){
			e.printStackTrace();
		}
	}

}
//no output
//because Object of DeserializationExample class is serialized 
//using writeObject() method and written to file.txt file