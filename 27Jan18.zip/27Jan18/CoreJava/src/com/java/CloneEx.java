package com.java;

public class CloneEx implements Cloneable {
	@Override
	protected Object clone() throws CloneNotSupportedException{
		return super.clone();
	}

	String name = "geeksforgeeks";
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CloneEx obj = new CloneEx();
		try{
			CloneEx obj2 = (CloneEx) obj.clone();
			System.out.println(obj2.name);
		}
		catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
	}

}
