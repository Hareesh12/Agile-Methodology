package com.java;

import java.lang.reflect.Constructor;

public class ReflectionExample {
	
	private String name;
	ReflectionExample(){
		
	}
	public void setname(String name){
		this.name=name;
	}
	public static void main(String []args){
		try{
			Constructor<ReflectionExample> constructor 
						=ReflectionExample.class.getDeclaredConstructor();
			ReflectionExample r = constructor.newInstance();
			r.setname("geeksforgeeks");
			System.out.println(r.name);
			
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
