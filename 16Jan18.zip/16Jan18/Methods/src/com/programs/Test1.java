package com.programs;
import java.io.*;
public class Test1 {
	public static int i =0;
	Test1(){
		i++;
	}
	public static int get(){
		return i;
	}

	public int m1(){
		System.out.println("Inside the method m1 by  object of gfg class");
		this.m2();
		return 1;
	}
		public void m2(){
			System.out.println("in method m2 came from m1");
			
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test1 obj = new Test1();
		int i =obj.m1();
		System.out.println("control returned after m1:"+ i);
		int number_of_objects= Test1.get();
		System.out.print("no of objects created till now:");
		System.out.println(number_of_objects);
	}

}
