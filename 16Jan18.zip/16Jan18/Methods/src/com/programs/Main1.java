package com.programs;

class Main1{
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Parent1 obj1=new Parent1();
		obj1.m2();
		Parent1 obj2=new Child1();
		obj2.m2();
		
	}

}
