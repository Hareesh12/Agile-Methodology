package com.programs;

class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent3 obj1=new Parent3();
		obj1.m1();
		obj1.m2();
		
		Child3 obj2=new Child3();
		obj2.m1();
		obj2.m2();
		
		

	}

}
