package com.programs;

public class Methods {
	int a =10;
	int b =20;
	
	void add(){
		System.out.println(a+b);
	
	}
	public static void main(String[]args){

	Methods m = new Methods();
	m.add();
	
}
}
