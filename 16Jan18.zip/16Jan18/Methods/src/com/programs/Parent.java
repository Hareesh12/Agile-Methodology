package com.programs;

class Parent {

	void show(){
		System.out.println("parent show()");
	}
}
	class Child extends Parent{
		@Override
		void show(){
			System.out.println("child show()");
		}
		}
	