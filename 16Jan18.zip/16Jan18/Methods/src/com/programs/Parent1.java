package com.programs;

public class Parent1 {

	 // private methods are not overridden
	private void m1(){
		System.out.println("from parent m1");
	}
	protected void m2(){
		System.out.println("from parent m2");
	}
}
	class Child1 extends Parent1{
		 // private methods are not overridden
	private void m1(){
		System.out.println("from child m1");
	}
	@Override
	public void m2(){
		System.out.println("from child m2");
	}
	}
	