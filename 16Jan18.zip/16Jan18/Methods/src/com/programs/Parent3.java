package com.programs;

public class Parent3 {
	static void m1(){
		System.out.println("From parent3 static m1()");
	}
	void m2(){
		System.out.println("From parent3 non-static(instance of)m2()");
	}

}
class Child3{
	static void m1(){
		System.out.println("From Child3 Static m1()");
	}
	void m2(){
		System.out.println("From child3 non-static(instance of) m2()");
	}
}
 