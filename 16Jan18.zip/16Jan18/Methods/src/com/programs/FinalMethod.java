package com.programs;

public class FinalMethod {

    // Can't be overridden
	final void show(){
		
	}

}
class Child2 extends FinalMethod{
    // This would produce error
	void show(){
		
	}
}
