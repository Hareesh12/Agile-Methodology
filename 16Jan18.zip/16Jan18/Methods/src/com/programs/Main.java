package com.programs;

class Main{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent obj1 = new Parent();
		obj1.show();
		Parent obj2 = new Child();
		obj2.show();

	}

}

