package AbstaractMethod;

public class Main1 {

	public static void main(String args[]){
		Derived1 d = new Derived1();
		d.fun();
		
	}
}
