package AbstaractMethod;
// abstract classes also can have final methods
abstract class Final {

	final void fun(){
		System.out.println("final fun called");
	}
}
class Start extends Final{

	

}
