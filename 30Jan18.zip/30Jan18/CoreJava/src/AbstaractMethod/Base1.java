package AbstaractMethod;

abstract class Base1 {

	abstract void fun();
	Base1(){
		System.out.println("Base1 constructor called");
	}
}
	class Derived1 extends Base1{
		Derived1(){
			System.out.println("Derived1 constructor called");
		}
		void fun(){
			System.out.println("Derived class");
		}
	}

