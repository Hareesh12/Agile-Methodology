package AbstaractMethod;
//abstract is a non access modifier in java,applicable for classes,methods
//but not variables
/*abstract modifiers:
 * final
 * abstract native
 * abstract synchronized
 * abstract static
 * abstract private
 * abstract strictfp
 */

//abstract class
abstract class A {
	abstract void m1();
	//concrete method
	void m2(){
		System.out.println("this is a concrete method");
	}
	

}
//concrete class
class B extends A{
	void m1(){
		System.out.println("B's implementation of m2");
		
	}
}
