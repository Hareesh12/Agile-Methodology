package AbstaractMethod;

abstract class Base2 {

	void fun(){
		System.out.println("Base2 fun called");
	}

}
class Derived2 extends Base2{
	
}
