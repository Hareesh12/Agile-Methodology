package AbstaractMethod;

public class Middile {

	public static void main(String args[]){
		Start s= new Start();
		s.fun();
	}
}
