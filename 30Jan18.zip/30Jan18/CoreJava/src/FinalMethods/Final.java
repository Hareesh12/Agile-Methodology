package FinalMethods;
//final variable cannot reassign, doing it will throw compile time error 
public class Final {

	final int CAPACITY=4;
	public static void main(String args[]){
		//reassigning final variable will throw compile time error
		CAPACITY=5;
	}
}
