package FinalMethods;

public class Final1 {

	public static void main(String args[]){
		final int a=10;
		System.out.println(a);
	}
}
