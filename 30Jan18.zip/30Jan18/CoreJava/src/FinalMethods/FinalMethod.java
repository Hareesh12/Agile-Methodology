package FinalMethods;

public class FinalMethod {
	public static void main(String args[]){
		final StringBuilder sb = new StringBuilder("geeks");
		System.out.println(sb);
		sb.append("forgeeks");
		System.out.println(sb);
	}

}
