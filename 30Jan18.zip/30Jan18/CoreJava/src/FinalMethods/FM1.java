package FinalMethods;
/*Final:
 * final keyword is used in different contexts,first
 * of all final is non access modifier applicable
 * only to a variable,a method or a class.
 * 
 */
public class FM1 {

	//a final variable direct initialize
	//final variable reference
	//final StringBuffer sb;
	final int THRESHOLD=5;
	//a blank final variable
	final int CAPACITY;
	//another blank final variable
	final int MINIMUM;
	//a final static variable direct initializer
	static final double PI=3.1457;
	//a blank static final variable
	static final double EUCONSTANT;
	
	//instance initializer block for initializing capacity
	{
		CAPACITY=5;
	}
	//static initializer block for initializing EUCONSTANT
	static{
		EUCONSTANT=4;
	}
	public FM1(){
		MINIMUM=-1;
	}
}
