package FinalMethods;
//final with for each loop
public class Final2 {

	public static void main(String args[]){
	int arr[]={1,2,4,5};
	for(final int i : arr)
	
	System.out.print(i +" ");
	
	}
}
