package com.overload;

public class Test {
	public static void oof(){
		System.out.println("test oof()");
	}
	public static void oof(int a){
		System.out.println("test oof(int a)");
			
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test obj = new Test();
		obj.oof();
		obj.oof(10);
	}

}
