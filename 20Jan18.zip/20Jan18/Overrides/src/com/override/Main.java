package com.override;

class Main{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent obj1 = new Grand();
		Parent obj2 = new Child();
		obj2.show();
		obj1.show();

	}

}

