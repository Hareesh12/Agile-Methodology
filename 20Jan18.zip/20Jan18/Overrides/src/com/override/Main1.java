package com.override;

public class Main1 {
	// This method can be used to print salary of
    // any type of employee using base class reference
	static void printSalary(Employee e){
		System.out.println(e.salary());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee ob1 = new Manager();
		System.out.print("Manager salary:");
		printSalary(ob1);
		
		Employee ob2 = new Clerk();
		System.out.print("Clerk salary:");
		printSalary(ob2);

	}

}
