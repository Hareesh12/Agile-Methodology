package com.override;

public class Employee {
	public static int base = 10000;
	int salary(){
		return base;
	}
}
class Manager extends Employee{
	int salary(){
		return base + 20000;
	}}
class Clerk extends Employee{
	int salary(){
		return base + 10000;
	}}