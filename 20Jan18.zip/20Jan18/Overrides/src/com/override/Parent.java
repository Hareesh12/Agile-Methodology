package com.override;

 class Parent {
	void show(){
		System.out.println("parent method");
	}
}
	class Child extends Parent{
		@Override
	void show(){
	System.out.println("child show");
	}
	}
	class Grand extends Child{
		void show(){
			System.out.println("Grand");
		}
	}
	