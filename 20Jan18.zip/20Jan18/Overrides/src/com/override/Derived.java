package com.override;

import java.io.IOException;

public class Derived {
	
	public void getDetails()throws IOException{
		System.out.println("Derived class");
		
	}
}
class Test extends Derived{
	public void getDetails()throws Exception{
		System.out.println("Test class");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Derived obj = new Test();
		obj.getDetails();
	}

}
//The exception thrown by the overriding method should not be new or 
//more broader checked exception. In the code above, Exception is 
//more broader class of checked exception than IOException, so this
//results in compilation error
