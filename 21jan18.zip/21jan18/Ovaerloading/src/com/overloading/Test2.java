package com.overloading;

public class Test2 {
	public int sum(int x, int y){
		return (x+y);
	}
	public int sum(int x ,int y ,int z){
		return(x+y+z);
	}

	public double sum(double x, double y){
		return (x+y);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test2 obj = new Test2();
		System.out.println(obj.sum(10,20));
		System.out.println(obj.sum(14,12,45));
		System.out.println(obj.sum(10.1,13.2));

	}

}
