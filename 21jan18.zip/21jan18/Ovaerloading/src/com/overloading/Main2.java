package com.overloading;

public class Main2 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hi geeks....");
		Main2.main("geek");

	}
	public static void main(String args1){
		System.out.println("Hi"+args1);
		Main2.main("ram","mahe");
	}
	public static void main(String args1, String args2){
		System.out.println("Hi,"+args1+","+args2);
		
		
	}

}
