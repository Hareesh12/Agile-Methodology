package com.overloading;

public class Test {

	public static void foo(){
		System.out.println("fooo");
	}
	public static void foo(int a){
		System.out.println("int a");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test obj=new Test();
		obj.foo();
		obj.foo(10);
	}

}
