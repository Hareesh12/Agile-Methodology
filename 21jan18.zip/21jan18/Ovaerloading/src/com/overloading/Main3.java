package com.overloading;

public class Main3 {
	public int add(int a,int b){
		int sum=a+b;
		return sum;
	}
	public int add(int a, int b,int c){
		int sum = a+b+c;
		return sum;
	}
}

