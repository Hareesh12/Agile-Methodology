package com.overloading;

public class Test1 {
	public static void foo(){
		System.out.println("foo");
	}
	public void foo(){// Compiler Error: cannot redefine foo()
		System.out.println("int a");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test.foo();
	}

}
