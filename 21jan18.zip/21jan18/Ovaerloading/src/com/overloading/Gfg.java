package com.overloading;

class Gfg{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Main3 ob=new Main3();
		int sum1 =ob.add(10, 23);
		System.out.println("sum="+sum1);
		int sum2 = ob.add(12, 41, 16);
		System.out.println("sum"+ sum2);
	}

}