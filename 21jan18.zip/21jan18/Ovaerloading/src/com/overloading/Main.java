package com.overloading;

public class Main {

	public int foo(){
		return 10;
	}
	public char foo(){
		return 'aa';
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
