package wrapperclass;

public class WrappingUnWrapping {
	public static void main(String args[]){
		byte a=1;
		//wrapping around byte object
		Byte byteobj= new Byte(a);
		int b=10;
		//wrapping around int object
		Integer integerobj = new Integer(b);
		float c=12.0f;
		//wrapping around float object
		Float floatobj= new Float(c);
		double d= 12.23;
		//wrapping around double object
		Double doubleobj= new Double(d);
		char e='s';
		//wrapping around character object
		Character charobj = new Character(e);
		
		System.out.println(byteobj);
		System.out.println(integerobj);
		System.out.println(floatobj);
		System.out.println(doubleobj);
		System.out.println(charobj);
		
		// objects to data types (retrieving data types from objects)
        // unwrapping objects to primitive data types
		byte bv =byteobj;
		int iv=integerobj;
		float fv=floatobj;
		double dv=doubleobj;
		char cv = charobj;
		System.out.println(bv);
		System.out.println(iv);
		System.out.println(fv);
		System.out.println(dv);
		System.out.println(cv);
	}

}
