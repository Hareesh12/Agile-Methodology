package com.staticClass;

public class OuterClass {

	private static String msg ="ram";
	//static nested class[
	
	public static class NestedStaticClass{
		//only static members of outer class is directly accessible in
		//nested static class
	public void printMessage(){
		//try making'message' a non-static variable, there will be 
		//compiler error
		System.out.println("Message from nested static class:" + msg);
	}
	}
	public class InnerClass{
		public void display(){
			System.out.println("non-static nested class:"+ msg);
		}
	}
	
	}

