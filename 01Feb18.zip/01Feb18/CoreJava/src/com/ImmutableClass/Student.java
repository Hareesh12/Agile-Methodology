package com.ImmutableClass;
//immutable class
public class Student {

	String name;
	int regNo;
	Student(String name,int regNo){
		this.name=name;
		this.regNo=regNo;
	}
	public String getname(){
		return name;
	}
	public int getregNo(){
		return regNo;
	}
	public static void main(String args[]){
		Student s=new Student("abhi",120);
		System.out.println(s.name);
		System.out.println(s.regNo);
	}
}
