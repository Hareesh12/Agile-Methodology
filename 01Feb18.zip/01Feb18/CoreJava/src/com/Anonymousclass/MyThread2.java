package com.Anonymousclass;
//Anonymous Inner class that defines inside method/constructor argument 
public class MyThread2 {
	public static void main(String args[]){

		//Here we are using Anonymous Inner class
        //that define inside argument, here constructor argument
		Thread t =new Thread(new Runnable(){
			
			public void run(){
				System.out.println("child thread");
			}
		});
				t.start();
				System.out.println("main thread");
				
				
				
	}

}
