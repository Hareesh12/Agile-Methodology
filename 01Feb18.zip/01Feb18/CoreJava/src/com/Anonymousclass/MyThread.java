package com.Anonymousclass;
//anonymous inner class that extends a class 
public class MyThread {

	public static void main(String args[]){
		//a thread is a thread of execution in a program
		Thread t = new Thread(){
			public void run(){
				System.out.println("child thread");
			}
		};
		//Causes this thread to begin execution;
		//the Java Virtual Machine calls the run method of this thread
		t.start();
		System.out.println("main thread");
	}
}
