package com.Anonymousclass;

class AnonymousDemo{
	public static void main(String args[]){
		
	
	MyClass obj = new MyClass();
	obj.getAge();
	
	}
}
class MyClass implements Age{
	@Override
	public void getAge(){
		System.out.println("Age is="+x);
	}
}
