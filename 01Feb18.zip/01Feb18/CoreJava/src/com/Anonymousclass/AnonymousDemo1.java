package com.Anonymousclass;

public class AnonymousDemo1 {
	public static void main(String args[]){
		Age ob1= new Age(){
			public void getAge(){	
				System.out.println("Age is="+x);
			}
		};
		ob1.getAge();
	}

}
//types of inner classes :
//Based on declaration and behavior,there are three 
//types of anonymous inner classes