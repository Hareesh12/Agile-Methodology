package com.Anonymousclass;
//anonymous inner class that extends a interface
public class MyThread1 {
	public static void main(String args[]){
		//The Runnable interface should be implemented by any class 
		//whose instances are intended 
		//to be executed by a thread. The class must define a method 
		//of no arguments called run
		
		
		//Here we are using Anonymous Inner class
        //that implements a interface i.e. Here Runnable interface
		Runnable r= new Runnable(){
			public void run(){
				System.out.println("child thread");
			}
		};
		Thread t =  new Thread(r);
		t.start();
		System.out.println("main thread");
	}

}
