package com.Anonymousclass;

public interface Age1 {
	int x= 21;
	void getAge();

}
