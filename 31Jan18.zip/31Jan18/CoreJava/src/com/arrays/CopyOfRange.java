package com.arrays;

import java.util.Arrays;

public class CopyOfRange {

	public static void main(String args[]){
		int ar[]={4,2,6,9,5,1,3};
		int[] copy= Arrays.copyOf(ar,ar.length);
		System.out.println("total array=" + Arrays.toString(copy));
		int [] rcopy=Arrays.copyOfRange(ar, 1, 5);
		System.out.println("1 to 5="+Arrays.toString(rcopy));
	}
}
