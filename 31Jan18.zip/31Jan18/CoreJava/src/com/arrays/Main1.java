package com.arrays;

import java.util.Arrays;
import java.util.List;

public class Main1 {

	public static void main(String args[]){
		Integer ar[]={3,1,5,7,9};
		List<Integer> l1=Arrays.asList(ar);
		System.out.println(l1);
	}
}
