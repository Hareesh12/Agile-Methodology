package com.arrays;

import java.util.Arrays;

public class Main {
	public static void main(String args[]){
		int ar[]={3,1,5,8,6};
		Arrays.fill(ar,0,3,0);
		System.out.println("Arrays filled with 0 from 0 to 3"+Arrays.toString(ar));
		Arrays.fill(ar,10);
		System.out.println("arrays completely filled="+Arrays.toString(ar));
	}

}
