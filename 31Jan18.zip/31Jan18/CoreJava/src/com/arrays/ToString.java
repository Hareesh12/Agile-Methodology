package com.arrays;

import java.util.Arrays;

public class ToString {

	
	public static void main(String args[]){
		int ar[]={1,5,41,2,9};
		System.out.println(Arrays.toString(ar));
	}
}
