package com.arrays;

import java.util.Arrays;

public class BinarySearch {
	public static void main(String args[]){
		int arr[]={4,2,1,7,5,9,5,8};
		Arrays.sort(arr);
		System.out.println("all ascending numbers="+Arrays.toString(arr));
		int index = Arrays.binarySearch(arr,9);
		System.out.println("position 9="+index);
	}

}
