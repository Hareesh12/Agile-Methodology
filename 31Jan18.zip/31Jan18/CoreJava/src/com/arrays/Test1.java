package com.arrays;

import java.util.Arrays;

public class Test1 {

	public static void main(String args[]){
		int arr[]={4,8,5,7,3,4,6,2,9,1};
		Arrays.sort(arr,0,4);
		System.out.println("sort from 0,4="+Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println("sorted all in ascending="+Arrays.toString(arr));
	}
}
