package com.operators;

public class UnaryOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10, b=20, c=13,d=0,e=40,f=12;
		boolean  condition = true;
		System.out.println("total c(++a)=" + ++a);
		
		System.out.println("total c(b++)=" + b++);
		System.out.println("sub c(--c)=" + --c);
		System.out.println("Value of !Condition =" + !condition);
	}

}
