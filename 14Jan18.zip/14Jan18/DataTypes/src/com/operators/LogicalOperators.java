package com.operators;

import java.util.Scanner;

public class LogicalOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x="ram";
		String y="1234";
		Scanner s= new Scanner(System.in);
		System.out.println("Enter UserName:");
		String uuid=s.next();
		System.out.println("Enter Password:");
		String upwd=s.next();
		if((uuid.equals(x)&&upwd.equals(y)||uuid.equals(y)&&upwd.equals(x))){
			System.out.println("welcome user");
		}else{
			System.out.println("wrong user name and passwordram");
		}

	}

}
