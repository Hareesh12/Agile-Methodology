package com.operators;

public class RelationalOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20,b=10;
		String x="thank", y= "thank";
		int ar[]={1,2,3};
		int br[]={1,2,3};
		boolean condition=true;
		System.out.println("a>b="+(a>b));
		System.out.println("a<b="+(a<b));
		System.out.println("a>=b="+(a>=b));
		System.out.println("a<=b="+(a<=b));
		System.out.println("a==b ="+(a==b));
		System.out.println("a!=b ="+(a!=b));
		System.out.println("x==y:"+(ar==br));
		System.out.println("condition is true="+ (condition=true));

	}

}
