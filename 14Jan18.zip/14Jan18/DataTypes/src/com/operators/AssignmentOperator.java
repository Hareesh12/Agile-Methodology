package com.operators;

public class AssignmentOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10, b=20,c, d, e=40,f=30,g=50;
		c=a;
		System.out.println("value of c =" + c);
		a+=1;
		b-=1;
		e*=2;
		f/=2;
		System.out.println("a,b,e,f =" + a +","+b+","+e+","+f);
		a=a+1;
		b=b-1;
		e=e*2;
		f=f/2;
		System.out.println("a,b,e,f values ="+ a+","+b+","+e+","+f);
		
	}

}
